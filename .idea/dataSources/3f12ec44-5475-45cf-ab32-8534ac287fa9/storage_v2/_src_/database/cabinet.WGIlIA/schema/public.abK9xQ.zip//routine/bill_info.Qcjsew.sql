create function bill_info(agreem text, spec text, datefrom date DEFAULT date_trunc('month'::text, now()), dateto date DEFAULT now(), OUT ondate date, OUT inclocal integer, OUT inczone integer, OUT local integer, OUT zone integer, OUT overlocal integer, OUT overzone integer, OUT avlocal integer, OUT avzone integer, OUT mgmn integer, OUT fixpay numeric, OUT sumlocal numeric, OUT sumzone numeric, OUT summgmn numeric) returns record
    language plpgsql
as
$$
DECLARE
    billinf RECORD;
    specinf RECORD;
BEGIN

    SELECT 
	CASE WHEN sum(nb.local) IS NULL THEN 0
	   ELSE sum(nb.local)/60 END AS loc,
	CASE WHEN sum(nb.zone) IS NULL THEN 0
	   ELSE sum(nb.zone)/60 END AS zon,
	CASE WHEN sum(nb.mg) IS NULL THEN 0
	   ELSE sum(nb.mg)/60 END AS mgmn,
	CASE WHEN sum(nb.summg) IS NULL THEN 0
	   ELSE sum(nb.summg) END AS summgmn
    INTO 
	billinf
    FROM
	numbers_bil AS nb
    WHERE
	agreement = agreem AND
	specification = spec AND
	date between datefrom AND dateto;
    
    SELECT
	* 
    INTO 
	specinf 
    FROM
	public.specifications 
    WHERE 
	agreement = agreem AND 
	specification = spec;

    IF FOUND THEN
	ondate = specinf.ondate;
	inclocal = specinf.inclocal;
	inczone = specinf.inczone;
	fixpay = specinf.fixpay;
	local = billinf.loc;
	zone = billinf.zon;
	mgmn = billinf.mgmn;
	summgmn = billinf.summgmn;
	IF local > inclocal THEN
	   overlocal = local - inclocal;
	   sumlocal = overlocal * specinf.tariflocal;
	   avlocal = 0;
	ELSE
	   overlocal = 0;
	   sumlocal = 0;
	   avlocal = inclocal - local;
	END IF;
	IF zone > inczone THEN
	   overzone = zone - inczone;
	   sumzone = overzone * specinf.tarifzone;
	   avzone = 0;
	ELSE
	   overzone = 0;
	   sumzone = 0;
	   avzone = inczone - zone;
	END IF;

    END IF;

END;
$$;

alter function bill_info(text, text, date, date, out date, out integer, out integer, out integer, out integer, out integer, out integer, out integer, out integer, out integer, out numeric, out numeric, out numeric, out numeric) owner to postgres;

