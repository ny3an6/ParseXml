create function clearpart(cdrpat text) returns void
    language plpgsql
as
$$
DECLARE
    row     varchar(500);
cdr_state varchar(500);
row_state varchar(500);
BEGIN


    FOR row IN 
select relname from pg_class where relname like '||cdrpat||%'
    LOOP
RAISE NOTICE 'Dropping table: %', row;
row_state := ' DROP TABLE ' || row::text || ';';
execute row_state;
        RAISE NOTICE 'Dropped table: %', row;
    END LOOP;
END;
$$;

alter function clearpart(text) owner to postgres;

