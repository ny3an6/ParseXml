create function client_numbers(agreement text)
    returns TABLE(number text, bind text, specification text, ondate date)
    cost 10
    rows 10
    language sql
as
$$
SELECT
  numb.number,
  numb.bind,
  numb.specification,
  spec.ondate 
FROM
(SELECT
  number,
  bind,
  specification
FROM
  public.numbers
WHERE
  agreement = $1) AS numb
INNER JOIN
(SELECT
  ondate,
  specification
FROM
  public.specifications
WHERE
  agreement = $1) AS spec
ON 
  numb.specification = spec.specification
ORDER BY
  number
$$;

alter function client_numbers(text) owner to postgres;

