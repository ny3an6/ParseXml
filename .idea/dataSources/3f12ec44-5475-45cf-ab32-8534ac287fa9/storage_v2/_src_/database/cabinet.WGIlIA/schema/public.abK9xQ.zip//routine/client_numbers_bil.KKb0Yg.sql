create function client_numbers_bil(agreement text, datefrom date DEFAULT date_trunc('month'::text, now()), dateto date DEFAULT now())
    returns TABLE(number text, bind text, specification text, local bigint, zone bigint, mgmn bigint)
    language sql
as
$$
SELECT
  numb.number,
  numb.bind,
  numb.specification,
  CASE WHEN bill.sumloc IS NULL THEN 0
    ELSE bill.sumloc END,
  CASE WHEN bill.sumzone IS NULL THEN 0
    ELSE bill.sumzone END,
  CASE WHEN bill.summg IS NULL THEN 0
    ELSE bill.summg END
FROM
(SELECT
  number,
  bind,
  specification
FROM
  public.numbers
WHERE
  agreement = $1) AS numb
LEFT JOIN
(SELECT
  number,
  sum(local)/60 AS sumloc,
  sum(zone)/60 AS sumzone,
  sum(mg)/60 AS summg
FROM
  public.numbers_bil
WHERE
  agreement = $1 AND
  date BETWEEN datefrom AND dateto
GROUP BY number) AS bill
ON 
  numb.number = bill.number
ORDER BY
  number
$$;

alter function client_numbers_bil(text, date, date) owner to postgres;

