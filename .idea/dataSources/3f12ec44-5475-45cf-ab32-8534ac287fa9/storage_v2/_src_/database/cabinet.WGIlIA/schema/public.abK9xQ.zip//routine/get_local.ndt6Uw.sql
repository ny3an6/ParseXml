create function get_local(text, text, date, date) returns text
    language plpgsql
as
$$
DECLARE
nagreem ALIAS FOR $1;
numb ALIAS FOR $2;
dateFrom ALIAS FOR $3;
dateTo ALIAS FOR $4;
result text;
BEGIN
SELECT sum(local) FROM numbers_bil WHERE agreement=nagreem AND number=numb AND date BETWEEN dateFrom AND dateTo INTO result;
RETURN result;
END;
$$;

alter function get_local(text, text, date, date) owner to postgres;

